package br.com.erudio.rest_with_spring_boot_and_java;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestWithSpringBootAndJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
